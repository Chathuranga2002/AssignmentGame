package Controler;

public interface Wepon {
    void shoot();

    int getScore();


}
